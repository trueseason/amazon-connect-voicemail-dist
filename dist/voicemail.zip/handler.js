'use strict';
const AWS = require('aws-sdk');
const lambda = new AWS.Lambda();

exports.handleRequest = async (event) => {
    try {
        console.log(JSON.stringify(event));
        if (!(event.eventType)) {
            let voicemailRequest = {
                streamARN: event.Details.ContactData.MediaStreams.Customer.Audio.StreamARN,
                startFragmentNum: event.Details.ContactData.MediaStreams.Customer.Audio.StartFragmentNumber,
                connectContactId: event.Details.ContactData.ContactId,
                connectCallerId: event.Details.ContactData.CustomerEndpoint.Address,
                connectDialedNumber: event.Details.ContactData.SystemEndpoint.Address,
                transcriptionEnabled: event.Details.ContactData.Attributes.transcribeCall === "true" ? true : false,
                saveCallRecording: event.Details.ContactData.Attributes.saveCallRecording === "false" ? false : true,
                languageCode: event.Details.ContactData.Attributes.languageCode === "es-US" ? "es-US" : "en-US",
                streamAudioFromCustomer: event.Details.ContactData.Attributes.streamAudioFromCustomer === "false" ? false : true,
                streamAudioToCustomer: event.Details.ContactData.Attributes.streamAudioToCustomer === "false" ? false : true
            };
            console.log("Voicemail Request: " + JSON.stringify(voicemailRequest));

            const params = {
                'FunctionName': process.env.VoicemailStreamingFunction,
                'InvokeArgs': JSON.stringify(voicemailRequest)
            };
            await lambda.invokeAsync(params).promise();
        }
        console.info("Event processed successfully.");
    }
    catch (err) {
        console.error("Failed to process event:", err);
        return {
            statusCode: 500,
            body: JSON.stringify({ 'result': 'Failed' }),
        };
    }

    return {
        statusCode: 200,
        body: JSON.stringify({ 'result': 'Success' }),
    };
};
